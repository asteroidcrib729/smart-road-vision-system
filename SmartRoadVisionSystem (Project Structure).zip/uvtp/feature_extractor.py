// feature_extractor.py
// TODO: Implement feature_extractor