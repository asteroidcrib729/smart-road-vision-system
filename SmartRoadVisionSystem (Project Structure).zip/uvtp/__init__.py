// __init__.py
// TODO: Implement __init__