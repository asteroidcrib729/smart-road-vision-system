// tracker_loop.py
// TODO: Implement tracker_loop