// session.py
// TODO: Implement session