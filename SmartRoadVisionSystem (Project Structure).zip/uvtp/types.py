// types.py
// TODO: Implement types